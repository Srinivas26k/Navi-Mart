"use client"

import { useState } from "react"
import { notFound } from "next/navigation"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { products } from "@/lib/mock-data"
import { useCart } from "@/app/contexts/cart-context"

interface ProductPageProps {
  params: {
    slug: string
  }
}

export default function ProductPage({ params }: ProductPageProps) {
  const [quantity, setQuantity] = useState(1)
  const [selectedImage, setSelectedImage] = useState(0)
  const { addToCart } = useCart()

  // Find product by slug
  const product = products.find((p) => p.slug === params.slug)

  if (!product) {
    notFound()
  }

  const handleAddToCart = () => {
    addToCart(product, quantity)
  }

  const reviews = [
    {
      id: 1,
      name: "Priya Sharma",
      avatar:
        "https://lh3.googleusercontent.com/aida-public/AB6AXuDmr6pzr0gl0zgbaOApxI43G7z2tKmIgnnd0aFkTYJuFNtYw9Xw0_Ph42WfkIikw4WltwrVKlRrQ2NlmFsIsz0LPEcUOIxcnGJAvc7sujWllkJsesWlSDEcy_LuzD7R25Idtu49l6MBYStaR5CO3DU8UQWuRi-7c-_j_Khq4dkoMcHsJNfgAzD_7xoL-2Voqd_GIuIU-ukosY1noBej-Sje0Ac0SNHY2UJ0ZaOmX7qSEeZw365B9V3_Fa8rjprjc_8Rc9C48QxRfbaI",
      rating: 5,
      date: "2 months ago",
      comment:
        "The best turmeric I've ever used! The color and flavor are so much richer than store-bought. I use it in all my curries and even in my morning lattes. Highly recommend!",
    },
    {
      id: 2,
      name: "Arjun Patel",
      avatar:
        "https://lh3.googleusercontent.com/aida-public/AB6AXuADN6jAFNav674EFCcazPLctSezhq4sCvIVuTmG3y9g1xo9m-u88Yo65AI3C7Kf-rwpGHdzHDVwDz9n2FeOEeUBMg_28EWuoLWBh-esEhPbL0soubXgw9kVGXRnF3eGJLGCn4rz6EzC8IDAxFQOgkcTf8EWtu-uTREJ_eo4FRyHko1qeZxVfkqX6UmfGflnjGCLmswiqPDhgw6Yg4fQ6rNGRxvbONNHz1j23SRlfc0gFuqe99LiuHex3bGvQcu08LhP1TUPeDc3KxdO",
      rating: 4,
      date: "3 months ago",
      comment:
        "Good quality turmeric, though I found the aroma slightly less intense than expected. Still, it's a great organic option and adds a nice flavor to my dishes.",
    },
  ]

  return (
    <div className="min-h-screen bg-[var(--background-color)]">
      <Header />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="text-sm text-[var(--text-secondary)] mb-6">
          <a className="hover:text-[var(--primary-color)]" href="/shop">
            Shop
          </a>
          <span className="mx-2">/</span>
          <span className="text-[var(--text-primary)]">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
              <img
                alt={product.name}
                className="w-full h-full object-cover cursor-pointer transition-transform duration-300 hover:scale-105"
                src={product.images[selectedImage] || "/placeholder.svg"}
              />
            </div>

            {/* Thumbnail Images */}
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  className={`aspect-square rounded-lg overflow-hidden border-2 transition-colors ${
                    selectedImage === index ? "border-[var(--primary-color)]" : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setSelectedImage(index)}
                >
                  <img
                    alt={`${product.name} view ${index + 1}`}
                    className="w-full h-full object-cover"
                    src={image || "/placeholder.svg"}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-[var(--text-primary)] mb-2 section-heading">{product.name}</h1>
              <p className="text-[var(--text-secondary)] leading-relaxed">{product.description}</p>
            </div>

            {/* Certifications */}
            <div className="flex items-center gap-2">
              <img
                alt="Organic"
                className="w-8 h-8"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuAYzkJ-eDHYkQLQuvVz-NzdfQq_Teo59qJ15Du4FILUYJXuCCpv6mG5JGS493bAi9c7F0pPW7Hu2a48jwdSYs7uv7w1KfIx9ZpZnNndgkbPxEULtLO1XBE0M2FIG6B4g0nP0rWNoJO-fqykw8rx802gvcqaQQeBPBpJrlRnDKZJ1Ff4iII103aqMeN1d4jg_HEvDwftJP50mfpRk3wGW4OeGaa3EpAGDj_KhguL_9Gmz-tVgg0WazH8-6GhZOMjHtcjFjtJ9yO_SzOB"
              />
              <span className="text-sm font-medium text-green-600">Certified Organic</span>
            </div>

            {/* Product Details */}
            <div className="space-y-4 pt-4 border-t border-gray-200">
              <h2 className="text-2xl font-semibold text-[var(--text-primary)] section-heading">Product Details</h2>
              <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
                <p className="font-medium text-[var(--text-secondary)]">Weight</p>
                <p className="text-[var(--text-primary)]">{product.weight}</p>
                <p className="font-medium text-[var(--text-secondary)]">Origin</p>
                <p className="text-[var(--text-primary)]">{product.origin}</p>
                <p className="font-medium text-[var(--text-secondary)]">Category</p>
                <p className="text-[var(--text-primary)] capitalize">{product.category}</p>
              </div>
            </div>

            {/* Price and Add to Cart */}
            <div className="space-y-4 pt-4 border-t border-gray-200">
              <p className="text-3xl font-bold text-[var(--primary-color)]">${product.price.toFixed(2)}</p>

              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <label className="text-sm font-medium text-[var(--text-primary)]" htmlFor="quantity">
                    Quantity:
                  </label>
                  <select
                    className="form-select w-24 rounded-lg border-gray-300 focus:border-[var(--primary-color)] focus:ring-1 focus:ring-[var(--primary-color)] transition duration-200"
                    id="quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                  >
                    {[1, 2, 3, 4, 5].map((num) => (
                      <option key={num} value={num}>
                        {num}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  className="flex-1 bg-[var(--primary-color)] text-white py-3 px-6 rounded-lg font-semibold hover:opacity-90 transition-opacity duration-200"
                  onClick={handleAddToCart}
                >
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Information */}
        <section className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Nutritional Information */}
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-[var(--text-primary)] section-heading">
              Nutritional Information
            </h2>
            <p className="text-sm text-[var(--text-secondary)]">per 100g serving</p>
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm border-t border-gray-200 pt-4">
              <p className="font-medium text-[var(--text-secondary)]">Energy</p>
              <p className="text-[var(--text-primary)]">354 kcal</p>
              <p className="font-medium text-[var(--text-secondary)]">Protein</p>
              <p className="text-[var(--text-primary)]">7.8g</p>
              <p className="font-medium text-[var(--text-secondary)]">Fat</p>
              <p className="text-[var(--text-primary)]">9.9g</p>
              <p className="font-medium text-[var(--text-secondary)]">Carbohydrates</p>
              <p className="text-[var(--text-primary)]">64.9g</p>
            </div>
          </div>

          {/* Customer Reviews */}
          <div className="space-y-6">
            <h2 className="text-2xl font-semibold text-[var(--text-primary)] section-heading">Customer Reviews</h2>

            {/* Rating Summary */}
            <div className="flex items-start gap-4">
              <div className="text-center">
                <p className="text-5xl font-extrabold text-[var(--text-primary)]">4.8</p>
                <div className="flex justify-center text-[var(--primary-color)] mb-1">
                  {[...Array(5)].map((_, i) => (
                    <svg key={i} className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-sm text-[var(--text-secondary)]">125 reviews</p>
              </div>

              <div className="flex-1 space-y-1">
                {[
                  { stars: 5, percentage: 70 },
                  { stars: 4, percentage: 20 },
                  { stars: 3, percentage: 5 },
                  { stars: 2, percentage: 3 },
                  { stars: 1, percentage: 2 },
                ].map(({ stars, percentage }) => (
                  <div key={stars} className="flex items-center gap-2">
                    <span className="text-sm text-[var(--text-secondary)] w-2">{stars}</span>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-[var(--secondary-color)] h-2 rounded-full"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-[var(--text-secondary)] w-8">{percentage}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Individual Reviews */}
        <section className="mt-12 space-y-8 border-t border-gray-200 pt-8">
          {reviews.map((review) => (
            <div key={review.id} className="flex items-start gap-4">
              <img
                alt={review.name}
                className="h-10 w-10 rounded-full object-cover"
                src={review.avatar || "/placeholder.svg"}
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-semibold text-[var(--text-primary)]">{review.name}</p>
                  <div className="flex text-[var(--primary-color)]">
                    {[...Array(review.rating)].map((_, i) => (
                      <svg key={i} className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                    ))}
                  </div>
                </div>
                <p className="text-sm text-[var(--text-secondary)] mb-2">{review.date}</p>
                <p className="text-[var(--text-primary)] leading-relaxed">{review.comment}</p>
              </div>
            </div>
          ))}
        </section>
      </main>

      <Footer />
    </div>
  )
}
